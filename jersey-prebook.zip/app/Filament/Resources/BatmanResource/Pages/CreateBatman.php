<?php

namespace App\Filament\Resources\BatmanResource\Pages;

use App\Filament\Resources\BatmanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBatman extends CreateRecord
{
    protected static string $resource = BatmanResource::class;
}
