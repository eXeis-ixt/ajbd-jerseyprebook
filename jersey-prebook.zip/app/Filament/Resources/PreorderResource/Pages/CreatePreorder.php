<?php

namespace App\Filament\Resources\PreorderResource\Pages;

use App\Filament\Resources\PreorderResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePreorder extends CreateRecord
{
    protected static string $resource = PreorderResource::class;
}
